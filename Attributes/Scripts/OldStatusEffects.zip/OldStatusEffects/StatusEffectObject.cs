using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using unityInventorySystem.Attribute; 
using unityInventorySystem; 


[CreateAssetMenu(fileName = "StatusEffect", menuName = "Status Effects/Default", order = 0)]
public class StatusEffectObject : ScriptableObject, IStatusDoable
{
    [SerializeField] string _Name = "";

    [TextArea(15, 20)]
    [SerializeField] string _Description = ""; 
    [SerializeField] Sprite _icon; 
    // [SerializeField] float  _duration; 

    public string Name {
        get {return _Name;}
    }

    public string Description {
        get {return _Description;}
    }

    public Sprite Icon {
        get {return _icon;}
    }

    public virtual bool DoUpdate(StatusEffectD statusEffectD, float dtime)
    {
        return false; 
    }

    public virtual void DoIfUpdated(int value)
    {
    }


}



public enum StatusEffectObjectType {
    Default, Attribute, RepeatOverTime, DamageOverTime, Buildup
}

/*

How can I implement a buildup of poison or something? 

Point base? 
[ ][ ][ ][ ][ ]
[X][X][ ][ ][ ]

Percent base?
30%

Confusion
Charm?

Fire (DamageOverTime)
Frozen (Maybe temperature stat?)
Slow (attribute)

Fear (Maybe later)

Adrenaline ? (Attribute) (maybe boost stats when near death)? Unlockable skill? 

Wet (Attribute)


*/